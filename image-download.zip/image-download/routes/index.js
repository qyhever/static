var express = require('express');
var path = require('path');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/image', function(req, res, next) {
  // res.attachment(path.resolve(__dirname, '../public/images/1467346157879.jpg'))
  // res.set('Content-Disposition', 'attachment; filename="test123.jpg"')
  res.set('Content-Type', 'image/jpeg')
  res.sendFile('1467346157879.jpg', {
    root: path.resolve(__dirname, '../public/images'),
    // dotfiles: 'images',
  }, err => {
    console.log(err)
  });
});

module.exports = router;
