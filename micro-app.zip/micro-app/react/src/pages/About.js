import React from 'react';

export default function() {
  return (
    <h2 className="app-nav-item" style={{ borderColor: 'green' }}>
      About
    </h2>
  );
}
