import React from 'react';

export default function() {
  return (
    <h2 className="app-nav-item" style={{ borderColor: 'red' }}>
      Home
    </h2>
  );
}
