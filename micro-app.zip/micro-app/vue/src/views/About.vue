<template>
  <div class="about">
    <h1>This is about page</h1>
  </div>
</template>

<style scoped>
  .about {
    color: #7265e6;
  }
</style>
