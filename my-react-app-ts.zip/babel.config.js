module.exports = {
  'presets': [
    [
      '@babel/preset-env',
      {
        'useBuiltIns': 'entry',
        'corejs': 3
      }
    ],
    'react-app'
  ],
  'plugins': [
    [
      'babel-plugin-import',
      {
        'libraryName': 'lodash',
        'libraryDirectory': '',
        'camel2DashComponentName': false
      },
      'lodash'
    ],
    [
      'babel-plugin-import',
      {
        'libraryName': 'antd',
        'libraryDirectory': 'es',
        'style': true
      },
      'antd'
    ],
    [
      '@babel/plugin-proposal-decorators',
      {
        'legacy': true
      }
    ],
    '@babel/plugin-proposal-optional-chaining',
    '@babel/plugin-proposal-nullish-coalescing-operator'
  ]
}