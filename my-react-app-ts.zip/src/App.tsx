import React from 'react';
import { Button } from 'antd';
import 'antd/dist/antd.css'

const App = () => (
  <div className="App">
    <Button type="primary">Button</Button>
  </div>
);

export default App;